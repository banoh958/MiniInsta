#ifndef MESSAGE_H
#define MESSAGE_H

#include "Stack.h"
#include <string>
#include <fstream>
#include <unordered_map>

class MessageSystem {
private:
    // Each user has a stack of messages for each conversation
    std::unordered_map<std::string, std::unordered_map<std::string, Stack<std::string>>> messages;

public:
    void sendMessage(const std::string& sender, const std::string& receiver, const std::string& message);
    std::string readLatestMessage(const std::string& user1, const std::string& user2);
    void printConversation(const std::string& user1, const std::string& user2);

    // File handling methods
    void saveMessagesToFile(const std::string& filePath);
    void loadMessagesFromFile(const std::string& filePath);
};

#endif // MESSAGE_H
