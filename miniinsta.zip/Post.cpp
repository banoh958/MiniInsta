#include "Post.h"
#include <iostream>

// Constructor
PostSystem::PostSystem() : head(nullptr) {}

// Destructor
PostSystem::~PostSystem() {
    while (head) {
        UserNode* temp = head;
        head = head->next;
        delete temp;
    }
}

// Find a user by username
PostSystem::UserNode* PostSystem::findUser(const std::string& username) {
    UserNode* current = head;
    while (current) {
        if (current->username == username) {
            return current;
        }
        current = current->next;
    }
    return nullptr;
}

// Add a post for a user
void PostSystem::addPost(const std::string& user, const std::string& content) {
    UserNode* userNode = findUser(user);
    if (!userNode) {
        // Create a new user node if the user doesn't exist
        userNode = new UserNode(user);
        userNode->next = head;
        head = userNode;
    }
    userNode->posts.push(content);
    std::cout << user << " added a new post: " << content << "\n";
}

// Show all posts of a user
void PostSystem::showUserPosts(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode || userNode->posts.isEmpty()) {
        std::cout << user << " has no posts.\n";
        return;
    }

    std::cout << user << "'s posts:\n";
    Stack<std::string> tempStack = userNode->posts;

    while (!tempStack.isEmpty()) {
        std::cout << "- " << tempStack.top() << "\n";
        tempStack.pop();
    }
}

// Generate a newsfeed for a user
void PostSystem::generateNewsfeed(const std::string& user, const PostSystem& followers) {
    std::cout << user << "'s newsfeed:\n";

    UserNode* current = followers.head;
    while (current) {
        if (!current->posts.isEmpty()) {
            std::cout << current->username << "'s latest post: " << current->posts.top() << "\n";
        }
        current = current->next;
    }
}
void PostSystem::savePostsToFile(const std::string& filePath) {
    std::ofstream outFile(filePath);
    if (!outFile) {
        std::cerr << "Error: Could not open file for saving posts.\n";
        return;
    }

    UserNode* current = head;
    while (current) {
        outFile << current->username << "\n"; // Save username
        Stack<std::string> tempStack = current->posts;

        while (!tempStack.isEmpty()) {
            outFile << "- " << tempStack.top() << "\n"; // Save each post
            tempStack.pop();
        }
        current = current->next;
    }
    outFile.close();
    std::cout << "Posts saved to " << filePath << ".\n";
}
void PostSystem::loadPostsFromFile(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile) {
        std::cerr << "Error: Could not open file for loading posts.\n";
        return;
    }

    std::string line, username, postContent;
    UserNode* currentUser = nullptr;

    while (std::getline(inFile, line)) {
        if (!line.empty() && line[0] != '-') {
            username = line; // Start of a new user
            currentUser = findUser(username);
            if (!currentUser) {
                currentUser = new UserNode(username);
                currentUser->next = head;
                head = currentUser;
            }
        }
        else {
            postContent = line.substr(2); // Remove "- " prefix
            currentUser->posts.push(postContent); // Add post to user's stack
        }
    }
    inFile.close();
    std::cout << "Posts loaded from " << filePath << ".\n";
}
