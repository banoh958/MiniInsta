//#include "Notification.h"
//#include <iostream>
//
//int main() {
//    NotificationSystem notificationSystem;
//
//    // Load notifications from file
//    notificationSystem.loadNotificationsFromFile("notifications_test.txt");
//
//    int choice;
//    std::string username, message;
//
//    do {
//        std::cout << "\n=== Notification System ===\n";
//        std::cout << "1. Add Notification\n";
//        std::cout << "2. Show Notifications\n";
//        std::cout << "3. Clear Notifications\n";
//        std::cout << "4. Exit\n";
//        std::cout << "Enter your choice: ";
//        std::cin >> choice;
//
//        switch (choice) {
//        case 1:
//            std::cout << "Enter username: ";
//            std::cin >> username;
//            std::cout << "Enter notification message: ";
//            std::cin.ignore();
//            std::getline(std::cin, message);
//            notificationSystem.addNotification(username, message);
//            break;
//
//        case 2:
//            std::cout << "Enter username to view notifications: ";
//            std::cin >> username;
//            notificationSystem.showNotifications(username);
//            break;
//
//        case 3:
//            std::cout << "Enter username to clear notifications: ";
//            std::cin >> username;
//            notificationSystem.clearNotifications(username);
//            break;
//
//        case 4:
//            notificationSystem.saveNotificationsToFile("notifications_test.txt");
//            std::cout << "Notifications saved. Exiting...\n";
//            break;
//
//        default:
//            std::cout << "Invalid choice. Please try again.\n";
//        }
//    } while (choice != 4);
//
//    return 0;
//}
