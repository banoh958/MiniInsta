#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>

class Graph {
private:
    struct Relationship {
        std::string relationType; // "friend", "follow", or "block"
        std::string status;       // "active", "pending", or "blocked"

        // Default constructor
        Relationship() : relationType("none"), status("none") {}

        // Parameterized constructor
        Relationship(const std::string& type, const std::string& stat)
            : relationType(type), status(stat) {
        }
    };

    std::unordered_map<std::string, std::unordered_map<std::string, Relationship>> graph;

public:
    void addFollowRequest(const std::string& from, const std::string& to);
    void acceptFollowRequest(const std::string& from, const std::string& to);
    void blockUser(const std::string& from, const std::string& to);
    void showConnections(const std::string& user);
    void suggestFriends(const std::string& user);
};

#endif // GRAPH_H
