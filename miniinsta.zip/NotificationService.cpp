//#include "Notification.h"
//#include <iostream>
//
//// Constructor
//NotificationSystem::NotificationSystem() : head(nullptr) {}
//
//// Destructor
//NotificationSystem::~NotificationSystem() {
//    while (head) {
//        UserNode* temp = head;
//        head = head->next;
//        delete temp;
//    }
//}
//
//// Find a user by username in the linked list
//NotificationSystem::UserNode* NotificationSystem::findUser(const std::string& username) {
//    UserNode* current = head;
//    while (current) {
//        if (current->username == username) {
//            return current;
//        }
//    }
//    return nullptr;
//}
//
//// Add a notification for a specific user
//void NotificationSystem::addNotification(const std::string& user, const std::string& message) {
//    UserNode* userNode = findUser(user);
//    if (!userNode) {
//        // Create a new user node if the user doesn't exist
//        userNode = new UserNode(user);
//        userNode->next = head;
//        head = userNode;
//    }
//    userNode->notifications.enqueue(message);
//    std::cout << "Notification added for " << user << ": " << message << "\n";
//}
//
//// Show all notifications for a specific user
//void NotificationSystem::showNotifications(const std::string& user) {
//    UserNode* userNode = findUser(user);
//    if (!userNode) {
//        std::cout << user << " has no notifications.\n";
//        return;
//    }
//
//    if (userNode->notifications.isEmpty()) {
//        std::cout << user << " has no notifications.\n";
//        return;
//    }
//
//    std::cout << user << "'s notifications:\n";
//    while (!userNode->notifications.isEmpty()) {
//        std::cout << "- " << userNode->notifications.front() << "\n";
//        userNode->notifications.dequeue();
//    }
//}
//
//// Clear all notifications for a specific user
//void NotificationSystem::clearNotifications(const std::string& user) {
//    UserNode* userNode = findUser(user);
//    if (!userNode) {
//        std::cout << "No notifications found for " << user << ".\n";
//        return;
//    }
//
//    while (!userNode->notifications.isEmpty()) {
//        userNode->notifications.dequeue();
//    }
//    std::cout << "All notifications cleared for " << user << ".\n";
//}
