#include "LinkedList.h"
#include <iostream>

template <typename T>
LinkedList<T>::LinkedList() : head(nullptr), tail(nullptr), size(0) {}

template <typename T>
LinkedList<T>::~LinkedList() {
    while (head != nullptr) {
        removeFront();  // Remove and delete each node
    }
    tail = nullptr; // Ensure the tail is also null
}
template <typename T>
void LinkedList<T>::addFront(T value) {
    Node<T>* newNode = new Node<T>(value);
    newNode->next = head;
    head = newNode;
    if (tail == nullptr) {
        tail = head;
    }
    size++;
}

template <typename T>
void LinkedList<T>::addBack(T value) {
    Node<T>* newNode = new Node<T>(value);
    if (tail != nullptr) {
        tail->next = newNode;
    }
    tail = newNode;
    if (head == nullptr) {
        head = tail;
    }
    size++;
}

template <typename T>
void LinkedList<T>::removeFront() {
    if (isEmpty()) {
        std::cerr << "Error: List is empty!\n";
        return;
    }
    Node<T>* temp = head;  // Store the node to be deleted
    head = head->next;     // Move the head pointer to the next node
    delete temp;           // Free the memory
    temp = nullptr;        // Prevent dangling pointer
    size--;

    if (head == nullptr) { // If the list is now empty, update the tail
        tail = nullptr;
    }
}

template <typename T>
void LinkedList<T>::removeBack() {
    if (isEmpty()) {
        std::cerr << "Error: List is empty!\n";
        return;
    }
    if (head == tail) {
        delete head;
        head = tail = nullptr;
    }
    else {
        Node<T>* temp = head;
        while (temp->next != tail) {
            temp = temp->next;
        }
        delete tail;
        tail = temp;
        tail->next = nullptr;
    }
    size--;
}

template <typename T>
T LinkedList<T>::getFront() {
    if (isEmpty()) {
        throw std::runtime_error("Error: List is empty!");
    }
    return head->data;
}

template <typename T>
T LinkedList<T>::getBack() {
    if (isEmpty()) {
        throw std::runtime_error("Error: List is empty!");
    }
    return tail->data;
}

template <typename T>
int LinkedList<T>::getSize() {
    return size;
}

template <typename T>
bool LinkedList<T>::isEmpty() {
    return size == 0;
}

template <typename T>
void LinkedList<T>::printList() {
    Node<T>* current = head;
    while (current != nullptr) {
        std::cout << current->data << " -> ";
        current = current->next;
    }
    std::cout << "NULL\n";
}
// Copy constructor
template <typename T>
LinkedList<T>::LinkedList(const LinkedList& other) : head(nullptr), tail(nullptr), size(0) {
    Node<T>* current = other.head;
    while (current) {
        addBack(current->data); // Recreate nodes in the same order
        current = current->next;
    }
}

// Copy assignment operator
template <typename T>
LinkedList<T>& LinkedList<T>::operator=(const LinkedList& other) {
    if (this == &other) return *this; // Handle self-assignment

    // Clear existing list
    while (!isEmpty()) {
        removeFront();
    }

    // Copy elements from the other list
    Node<T>* current = other.head;
    while (current) {
        addBack(current->data);
        current = current->next;
    }

    return *this;
}
// Explicit instantiation for common data types
template class LinkedList<int>;
template class LinkedList<std::string>;
