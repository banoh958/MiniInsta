#include "MiniInstagram.h"

int main() {
    MiniInstagram app;
    app.run(); // Start the Mini Instagram application
    return 0;
}
