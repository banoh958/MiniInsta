#ifndef MINIINSTAGRAM_H
#define MINIINSTAGRAM_H

#include "SearchUser.h"
#include "Graph.h"
#include "Post.h"
#include "Message.h"
#include "Notification.h"

class MiniInstagram {
private:
    SearchUserSystem userSystem;           // User management
    Graph followSystem;                    // Follow requests and suggestions
    PostSystem postSystem;                 // Post management
    MessageSystem messageSystem;           // Messaging
    NotificationSystem notificationSystem; // Notifications
    std::string currentUser;               // Track logged-in user

    // Helper methods for handling logged-in user state
    bool isLoggedIn() const;

public:
    MiniInstagram();
    ~MiniInstagram();

    void displayMenu();
    void run();

    // Handlers for different functionalities
    void handleSignup();
    void handleLogin();
    void handleLogout();
    void handlePosts();
    void handleMessaging();
    void handleFollowRequests();
    void handleFriendSuggestions();
    void handleNotifications();
};

#endif // MINIINSTAGRAM_H
