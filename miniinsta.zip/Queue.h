#ifndef QUEUE_H
#define QUEUE_H

#include "LinkedList.h"

template <typename T>
class Queue {
private:
    LinkedList<T> list; // Using LinkedList as the base for the Queue

public:
    Queue();
    void enqueue(T value);
    void dequeue();
    T front();
    T back();
    int size();
    bool isEmpty();
    void printQueue();
};

#endif // QUEUE_H
