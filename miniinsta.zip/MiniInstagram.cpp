#include "MiniInstagram.h"
#include <iostream>
#include <string>

// Constructor: Load data from files
MiniInstagram::MiniInstagram() : currentUser("") {
    userSystem.loadUsersFromFile("users.txt");
    postSystem.loadPostsFromFile("posts.txt");
    followSystem = Graph(); // Initialize the follow system
    messageSystem.loadMessagesFromFile("messages.txt");
    notificationSystem.loadNotificationsFromFile("notifications.txt");
}

// Destructor: Save data to files
MiniInstagram::~MiniInstagram() {
    userSystem.saveUsersToFile("users.txt");
    postSystem.savePostsToFile("posts.txt");
    messageSystem.saveMessagesToFile("messages.txt");
    notificationSystem.saveNotificationsToFile("notifications.txt");
}

// Display the main menu
void MiniInstagram::displayMenu() {
    std::cout << "\n=== Mini Instagram ===\n";
    std::cout << "1. Signup\n";
    std::cout << "2. Login\n";
    std::cout << "3. Logout\n";
    std::cout << "4. Posts\n";
    std::cout << "5. Messaging\n";
    std::cout << "6. Follow Requests\n";
    std::cout << "7. Friend Suggestions\n";
    std::cout << "8. Notifications\n";
    std::cout << "9. Exit\n";
}

// Run the main menu loop
void MiniInstagram::run() {
    int choice;

    do {
        displayMenu();
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1: handleSignup(); break;
        case 2: handleLogin(); break;
        case 3: handleLogout(); break;
        case 4: handlePosts(); break;
        case 5: handleMessaging(); break;
        case 6: handleFollowRequests(); break;
        case 7: handleFriendSuggestions(); break;
        case 8: handleNotifications(); break;
        case 9:
            std::cout << "Exiting Mini Instagram. Goodbye!\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 9);
}

// Check if a user is logged in
bool MiniInstagram::isLoggedIn() const {
    if (currentUser.empty()) {
        std::cout << "Please login to access this feature.\n";
        return false;
    }
    return true;
}

// Handle user signup
void MiniInstagram::handleSignup() {
    std::string username, password;
    std::cout << "Enter username: ";
    std::cin >> username;
    std::cout << "Enter password: ";
    std::cin >> password;
    userSystem.addUser(username, password);
}

// Handle user login
void MiniInstagram::handleLogin() {
    if (!currentUser.empty()) {
        std::cout << "A user is already logged in as " << currentUser << ". Logout first.\n";
        return;
    }

    std::string username, password;
    std::cout << "Enter username: ";
    std::cin >> username;
    std::cout << "Enter password: ";
    std::cin >> password;

    if (userSystem.login(username, password)) {
        currentUser = username;
        std::cout << "Login successful. Welcome, " << currentUser << "!\n";
    }
    else {
        std::cout << "Invalid username or password.\n";
    }
}

// Handle user logout
void MiniInstagram::handleLogout() {
    if (currentUser.empty()) {
        std::cout << "No user is currently logged in.\n";
        return;
    }
    std::cout << currentUser << " logged out successfully.\n";
    currentUser = "";
}

// Handle posts
void MiniInstagram::handlePosts() {
    if (!isLoggedIn()) return;

    int choice;
    std::cout << "1. Add Post\n2. View Newsfeed\nEnter your choice: ";
    std::cin >> choice;

    if (choice == 1) {
        std::string content;
        std::cout << "Enter post content: ";
        std::cin.ignore();
        std::getline(std::cin, content);
        postSystem.addPost(currentUser, content);
    }
    else if (choice == 2) {
        postSystem.generateNewsfeed(currentUser, postSystem);
    }
    else {
        std::cout << "Invalid choice.\n";
    }
}

// Handle messaging
void MiniInstagram::handleMessaging() {
    if (!isLoggedIn()) return;

    int choice;
    std::string recipient, message;

    std::cout << "1. Send Message\n2. View Conversation\nEnter your choice: ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Enter recipient: ";
        std::cin >> recipient;
        std::cout << "Enter message: ";
        std::cin.ignore();
        std::getline(std::cin, message);
        messageSystem.sendMessage(currentUser, recipient, message);
    }
    else if (choice == 2) {
        std::cout << "Enter conversation partner: ";
        std::cin >> recipient;
        messageSystem.printConversation(currentUser, recipient);
    }
    else {
        std::cout << "Invalid choice.\n";
    }
}

// Handle follow requests
void MiniInstagram::handleFollowRequests() {
    if (!isLoggedIn()) return;

    int choice;
    std::string target;

    std::cout << "1. Send Follow Request\n2. Accept Follow Request\nEnter your choice: ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Enter username to send a follow request: ";
        std::cin >> target;
        followSystem.addFollowRequest(currentUser, target);
    }
    else if (choice == 2) {
        std::cout << "Enter username whose request you want to accept: ";
        std::cin >> target;
        followSystem.acceptFollowRequest(target, currentUser);
    }
    else {
        std::cout << "Invalid choice.\n";
    }
}

// Handle friend suggestions
void MiniInstagram::handleFriendSuggestions() {
    if (!isLoggedIn()) return;
    followSystem.suggestFriends(currentUser);
}

// Handle notifications
void MiniInstagram::handleNotifications() {
    if (!isLoggedIn()) return;
    notificationSystem.showNotifications(currentUser);
}
