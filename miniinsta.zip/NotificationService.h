//#ifndef NOTIFICATION_H
//#define NOTIFICATION_H
//
//#include "Queue.h"
//#include <string>
//
//class NotificationSystem {
//private:
//    // Node to represent a user and their notifications
//    struct UserNode {
//        std::string username;
//        Queue<std::string> notifications;
//        UserNode* next;
//
//        UserNode(const std::string& name) : username(name), next(nullptr) {}
//    };
//
//    UserNode* head; // Head of the linked list of users
//
//    UserNode* findUser(const std::string& username);
//
//public:
//    NotificationSystem();
//    ~NotificationSystem();
//
//    void addNotification(const std::string& user, const std::string& message);
//    void showNotifications(const std::string& user);
//    void clearNotifications(const std::string& user);
//};
//
//#endif // NOTIFICATION_H
