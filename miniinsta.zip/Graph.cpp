#include "Graph.h"

// Add a follow request
void Graph::addFollowRequest(const std::string& from, const std::string& to) {
    if (graph[from][to].status == "active") {
        std::cout << from << " is already following " << to << ".\n";
        return;
    }
    graph[from][to] = Relationship("follow", "pending");
    graph[to][from] = Relationship("follow", "pending");
    std::cout << from << " sent a follow request to " << to << ".\n";
}

// Accept a follow request
void Graph::acceptFollowRequest(const std::string& from, const std::string& to) {
    if (graph[from][to].status != "pending") {
        std::cout << "No pending follow request from " << from << " to " << to << ".\n";
        return;
    }
    graph[from][to].status = "active";
    graph[to][from].status = "active";
    std::cout << to << " accepted the follow request from " << from << ".\n";
}

// Block a user
void Graph::blockUser(const std::string& from, const std::string& to) {
    graph[from][to] = Relationship("block", "blocked");
    graph[to][from] = Relationship("block", "blocked");
    std::cout << from << " blocked " << to << ".\n";
}

// Show all connections for a user
void Graph::showConnections(const std::string& user) {
    if (graph[user].empty()) {
        std::cout << user << " has no connections.\n";
        return;
    }

    std::cout << user << "'s connections:\n";
    for (const auto& connection : graph[user]) {
        const auto& status = connection.second.status;
        const auto& relationType = connection.second.relationType;
        std::cout << "- " << connection.first << ": " << relationType << " (" << status << ")\n";
    }
}

// Suggest friends based on mutual connections
void Graph::suggestFriends(const std::string& user) {
    if (graph[user].empty()) {
        std::cout << "No connections to suggest for " << user << ".\n";
        return;
    }

    std::unordered_map<std::string, int> mutualCount;

    // Check second-degree connections
    for (const auto& friendPair : graph[user]) {
        const auto& friendName = friendPair.first;

        if (graph[user][friendName].status == "active") {
            for (const auto& mutual : graph[friendName]) {
                if (mutual.first != user && graph[user][mutual.first].status != "active") {
                    mutualCount[mutual.first]++;
                }
            }
        }
    }

    // Display suggestions
    if (mutualCount.empty()) {
        std::cout << "No mutual friends to suggest for " << user << ".\n";
        return;
    }

    std::cout << "Friend suggestions for " << user << ":\n";
    for (const auto& suggestion : mutualCount) {
        std::cout << "- " << suggestion.first << " (" << suggestion.second << " mutual connections)\n";
    }
}
