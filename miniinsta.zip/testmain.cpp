//#include "LinkedList.h"
//#include "Queue.h"
//#include "Stack.h"
//#include "BST.h"
//#include "Graph.h"
//#include "Message.h"
//#include "Notification.h"
//#include "FriendRequest.h"
//#include "Post.h"
//#include "SearchUser.h"
//#include <iostream>
//
//int main() {
//    std::cout << "=== Testing Search Users System ===\n";
//    SearchUserSystem searchUserSystem;
//
//    // Add users
//    searchUserSystem.addUser("alice");
//    searchUserSystem.addUser("bob");
//    searchUserSystem.addUser("charlie");
//    searchUserSystem.addUser("dave");
//
//    // Display all users
//    searchUserSystem.displayAllUsers();
//
//    // Search for specific users
//    std::cout << "Searching for 'bob': "
//        << (searchUserSystem.searchUser("bob") ? "Found" : "Not Found") << "\n";
//    std::cout << "Searching for 'eve': "
//        << (searchUserSystem.searchUser("eve") ? "Found" : "Not Found") << "\n";
//
//    return 0;
//}