#ifndef LINKEDLIST_H
#define LINKEDLIST_H

// Node class for Linked List
template <typename T>
class Node {
public:
    T data;
    Node* next;

    Node(T value) : data(value), next(nullptr) {}
};

// Linked List class
template <typename T>
class LinkedList {
private:
    Node<T>* head;
    Node<T>* tail;
    int size;

public:
    LinkedList();
    ~LinkedList();

    void addFront(T value);
    void addBack(T value);
    void removeFront();
    void removeBack();
    T getFront();
    T getBack();
    int getSize();
    bool isEmpty();
    void printList();
    LinkedList(const LinkedList& other);     // Copy constructor
    LinkedList& operator=(const LinkedList& other); // Copy assignment operator
};

#endif // LINKEDLIST_H
