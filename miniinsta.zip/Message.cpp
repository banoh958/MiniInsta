#include "Message.h"
#include <iostream>

void MessageSystem::sendMessage(const std::string& sender, const std::string& receiver, const std::string& message) {
    // Add the message to both users' conversation stacks
    messages[sender][receiver].push("You: " + message);
    messages[receiver][sender].push(sender + ": " + message);
    std::cout << "Message sent from " << sender << " to " << receiver << ".\n";
}

std::string MessageSystem::readLatestMessage(const std::string& user1, const std::string& user2) {
    if (messages[user1][user2].isEmpty()) {
        return "No messages in this conversation.";
    }
    return messages[user1][user2].top();
}

void MessageSystem::printConversation(const std::string& user1, const std::string& user2) {
    if (messages[user1][user2].isEmpty()) {
        std::cout << "No messages in this conversation.\n";
        return;
    }

    Stack<std::string> tempStack;

    // Reverse stack content for printing without affecting the original
    while (!messages[user1][user2].isEmpty()) {
        tempStack.push(messages[user1][user2].top());
        messages[user1][user2].pop();
    }

    std::cout << "Conversation between " << user1 << " and " << user2 << ":\n";
    while (!tempStack.isEmpty()) {
        std::cout << tempStack.top() << "\n";
        messages[user1][user2].push(tempStack.top()); // Restore original stack
        tempStack.pop();
    }
}

void MessageSystem::saveMessagesToFile(const std::string& filePath) {
    std::ofstream outFile(filePath);
    if (!outFile) {
        std::cerr << "Error: Could not open file for saving messages.\n";
        return;
    }

    for (const auto& senderPair : messages) {
        const std::string& sender = senderPair.first;

        for (const auto& receiverPair : senderPair.second) {
            const std::string& receiver = receiverPair.first;
            Stack<std::string> tempStack = receiverPair.second;

            // Save conversation header
            outFile << sender << " -> " << receiver << "\n";

            // Save messages in order (LIFO reversal)
            Stack<std::string> reversedStack;
            while (!tempStack.isEmpty()) {
                reversedStack.push(tempStack.top());
                tempStack.pop();
            }
            while (!reversedStack.isEmpty()) {
                outFile << "- " << reversedStack.top() << "\n";
                reversedStack.pop();
            }
        }
    }

    outFile.close();
    std::cout << "Messages saved to " << filePath << ".\n";
}
void MessageSystem::loadMessagesFromFile(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile) {
        std::cerr << "Error: Could not open file for loading messages.\n";
        return;
    }

    std::string line, sender, receiver, message;
    while (std::getline(inFile, line)) {
        if (!line.empty() && line.find("->") != std::string::npos) {
            // Extract sender and receiver
            size_t arrowPos = line.find("->");
            sender = line.substr(0, arrowPos - 1);
            receiver = line.substr(arrowPos + 3);
        }
        else if (!line.empty() && line[0] == '-') {
            // Extract message content (removing "- " prefix)
            message = line.substr(2);
            messages[sender][receiver].push(message); // Add to the stack
        }
    }

    inFile.close();
    std::cout << "Messages loaded from " << filePath << ".\n";
}
