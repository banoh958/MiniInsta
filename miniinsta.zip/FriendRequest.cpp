#include "FriendRequest.h"
#include <iostream>

// Constructor
FriendRequestSystem::FriendRequestSystem() : head(nullptr) {}

// Destructor
FriendRequestSystem::~FriendRequestSystem() {
    while (head) {
        UserNode* temp = head;
        head = head->next;
        delete temp;
    }
}

// Find a user by username
FriendRequestSystem::UserNode* FriendRequestSystem::findUser(const std::string& username) {
    UserNode* current = head;
    while (current) {
        if (current->username == username) {
            return current;
        }
        current = current->next;
    }
    return nullptr;
}

// Send a friend request
void FriendRequestSystem::sendFriendRequest(const std::string& from, const std::string& to) {
    UserNode* toUser = findUser(to);
    if (!toUser) {
        // Create a new user node if the recipient doesn't exist
        toUser = new UserNode(to);
        toUser->next = head;
        head = toUser;
    }
    toUser->friendRequests.enqueue(from);
    std::cout << from << " sent a friend request to " << to << ".\n";
}

// Show all pending friend requests for a user
void FriendRequestSystem::showFriendRequests(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode) {
        std::cout << user << " has no friend requests.\n";
        return;
    }

    if (userNode->friendRequests.isEmpty()) {
        std::cout << user << " has no friend requests.\n";
        return;
    }

    std::cout << user << "'s pending friend requests:\n";
    Queue<std::string> tempQueue = userNode->friendRequests;

    while (!tempQueue.isEmpty()) {
        std::cout << "- " << tempQueue.front() << "\n";
        tempQueue.dequeue();
    }
}

// Accept the first friend request
void FriendRequestSystem::acceptFriendRequest(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode || userNode->friendRequests.isEmpty()) {
        std::cout << user << " has no friend requests to accept.\n";
        return;
    }

    std::string requester = userNode->friendRequests.front();
    userNode->friendRequests.dequeue();
    std::cout << user << " accepted the friend request from " << requester << ".\n";
}

// Reject the first friend request
void FriendRequestSystem::rejectFriendRequest(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode || userNode->friendRequests.isEmpty()) {
        std::cout << user << " has no friend requests to reject.\n";
        return;
    }

    std::string requester = userNode->friendRequests.front();
    userNode->friendRequests.dequeue();
    std::cout << user << " rejected the friend request from " << requester << ".\n";
}
void FriendRequestSystem::saveFriendRequestsToFile(const std::string& filePath) {
    std::ofstream outFile(filePath);
    if (!outFile) {
        std::cerr << "Error: Could not open file for saving friend requests.\n";
        return;
    }

    UserNode* current = head;
    while (current) {
        outFile << current->username << "\n"; // Save username
        Queue<std::string> tempQueue = current->friendRequests;

        while (!tempQueue.isEmpty()) {
            outFile << "- " << tempQueue.front() << "\n"; // Save each friend request
            tempQueue.dequeue();
        }
        current = current->next;
    }
    outFile.close();
    std::cout << "Friend requests saved to " << filePath << ".\n";
}
void FriendRequestSystem::loadFriendRequestsFromFile(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile) {
        std::cerr << "Error: Could not open file for loading friend requests.\n";
        return;
    }

    std::string line, username, friendRequest;
    UserNode* currentUser = nullptr;

    while (std::getline(inFile, line)) {
        if (!line.empty() && line[0] != '-') {
            username = line; // Start of a new user
            currentUser = findUser(username);
            if (!currentUser) {
                currentUser = new UserNode(username);
                currentUser->next = head;
                head = currentUser;
            }
        }
        else {
            friendRequest = line.substr(2); // Remove "- " prefix
            currentUser->friendRequests.enqueue(friendRequest); // Add request to user's queue
        }
    }
    inFile.close();
    std::cout << "Friend requests loaded from " << filePath << ".\n";
}
