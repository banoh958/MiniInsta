#include "SearchUser.h"
#include <iostream>
#include <functional>

// Constructor
SearchUserSystem::SearchUserSystem() : root(nullptr) {}

// Destructor
SearchUserSystem::~SearchUserSystem() {
    clear(root);
}

// Helper function to clean up memory
void SearchUserSystem::clear(Node* node) {
    if (node) {
        clear(node->left);
        clear(node->right);
        delete node;
    }
}

// Insert a new user into the BST
void SearchUserSystem::insert(Node*& node, const std::string& username, const std::string& password) {
    if (!node) {
        node = new Node(username, password);
        return;
    }
    if (username < node->username) {
        insert(node->left, username, password);
    }
    else if (username > node->username) {
        insert(node->right, username, password);
    }
}

// Add a new user
void SearchUserSystem::addUser(const std::string& username, const std::string& password) {
    if (password.length() < 6) {
        std::cout << "Error: Password must be at least 6 characters long.\n";
        return;
    }
    insert(root, username, password);
    std::cout << "User " << username << " added.\n";
}

// Search for a user by username and password
bool SearchUserSystem::search(Node* node, const std::string& username, const std::string& password) {
    if (!node) {
        return false;
    }
    if (node->username == username && node->password == password) {
        return true;
    }
    if (username < node->username) {
        return search(node->left, username, password);
    }
    else {
        return search(node->right, username, password);
    }
}

// Login method
bool SearchUserSystem::login(const std::string& username, const std::string& password) {
    return search(root, username, password);
}

// In-order traversal to display all users
void SearchUserSystem::inorderTraversal(Node* node) {
    if (node) {
        inorderTraversal(node->left);
        std::cout << node->username << "\n";
        inorderTraversal(node->right);
    }
}

// Display all users
void SearchUserSystem::displayAllUsers() {
    if (!root) {
        std::cout << "No users found.\n";
        return;
    }
    std::cout << "All users (sorted):\n";
    inorderTraversal(root);
}

// Save users to file
void SearchUserSystem::saveUsersToFile(const std::string& filePath) {
    std::ofstream outFile(filePath);
    if (!outFile) {
        std::cerr << "Error: Could not open file for saving users.\n";
        return;
    }

    std::function<void(Node*, std::ofstream&)> saveInOrder = [&](Node* node, std::ofstream& file) {
        if (!node) return;
        saveInOrder(node->left, file);
        file << node->username << " " << node->password << "\n"; // Save username and password
        saveInOrder(node->right, file);
        };

    saveInOrder(root, outFile);
    outFile.close();
    std::cout << "Users saved to " << filePath << ".\n";
}

// Load users from file
void SearchUserSystem::loadUsersFromFile(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile) {
        std::cerr << "Error: Could not open file for loading users.\n";
        return;
    }

    std::string username, password;
    while (inFile >> username >> password) {
        addUser(username, password);
    }
    inFile.close();
    std::cout << "Users loaded from " << filePath << ".\n";
}
