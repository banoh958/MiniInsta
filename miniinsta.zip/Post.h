#ifndef POST_H
#define POST_H

#include "Stack.h"
#include <string>
#include <fstream>
class PostSystem {
private:
    struct UserNode {
        std::string username;
        Stack<std::string> posts; // Stack to hold user's posts
        UserNode* next;

        UserNode(const std::string& name) : username(name), next(nullptr) {}
    };

    UserNode* head; // Head of the linked list of users

    UserNode* findUser(const std::string& username);

public:
    PostSystem();
    ~PostSystem();

    void addPost(const std::string& user, const std::string& content);
    void showUserPosts(const std::string& user);
    void generateNewsfeed(const std::string& user, const PostSystem& followers);
    // File handling methods
    void savePostsToFile(const std::string& filePath);
    void loadPostsFromFile(const std::string& filePath);
};

#endif // POST_H
