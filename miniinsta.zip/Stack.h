#ifndef STACK_H
#define STACK_H

#include "LinkedList.h"

template <typename T>
class Stack {
private:
    LinkedList<T> list; // Using LinkedList as the base for the Stack

public:
    Stack();
    void push(T value);
    void pop();
    T top();
    int size();
    bool isEmpty();
    void printStack();
};

#endif // STACK_H
