#include "Notification.h"
#include <iostream>

// Constructor
NotificationSystem::NotificationSystem() : head(nullptr) {}

// Destructor
NotificationSystem::~NotificationSystem() {
    while (head) {
        UserNode* temp = head;
        head = head->next;
        delete temp;
    }
}

// Find a user by username in the linked list
NotificationSystem::UserNode* NotificationSystem::findUser(const std::string& username) {
    UserNode* current = head;
    while (current) {
        if (current->username == username) {
            return current;
        }
    }
    return nullptr;
}

// Add a notification for a specific user
void NotificationSystem::addNotification(const std::string& user, const std::string& message) {
    UserNode* userNode = findUser(user);
    if (!userNode) {
        // Create a new user node if the user doesn't exist
        userNode = new UserNode(user);
        userNode->next = head;
        head = userNode;
    }
    userNode->notifications.enqueue(message);
    std::cout << "Notification added for " << user << ": " << message << "\n";
}

// Show all notifications for a specific user
void NotificationSystem::showNotifications(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode) {
        std::cout << user << " has no notifications.\n";
        return;
    }

    if (userNode->notifications.isEmpty()) {
        std::cout << user << " has no notifications.\n";
        return;
    }

    std::cout << user << "'s notifications:\n";
    while (!userNode->notifications.isEmpty()) {
        std::cout << "- " << userNode->notifications.front() << "\n";
        userNode->notifications.dequeue();
    }
}

// Clear all notifications for a specific user
void NotificationSystem::clearNotifications(const std::string& user) {
    UserNode* userNode = findUser(user);
    if (!userNode) {
        std::cout << "No notifications found for " << user << ".\n";
        return;
    }

    while (!userNode->notifications.isEmpty()) {
        userNode->notifications.dequeue();
    }
    std::cout << "All notifications cleared for " << user << ".\n";
}
void NotificationSystem::saveNotificationsToFile(const std::string& filePath) {
    std::ofstream outFile(filePath);
    if (!outFile) {
        std::cerr << "Error: Could not open file for saving notifications.\n";
        return;
    }

    UserNode* current = head;
    while (current) {
        outFile << current->username << "\n"; // Save username
        Queue<std::string> tempQueue = current->notifications;

        while (!tempQueue.isEmpty()) {
            outFile << "- " << tempQueue.front() << "\n"; // Save each notification
            tempQueue.dequeue();
        }
        current = current->next;
    }

    outFile.close();
    std::cout << "Notifications saved to " << filePath << ".\n";
}
void NotificationSystem::loadNotificationsFromFile(const std::string& filePath) {
    std::ifstream inFile(filePath);
    if (!inFile) {
        std::cerr << "Error: Could not open file for loading notifications.\n";
        return;
    }

    std::string line, username, notification;
    UserNode* currentUser = nullptr;

    while (std::getline(inFile, line)) {
        if (!line.empty() && line[0] != '-') {
            // New user
            username = line;
            currentUser = findUser(username);
            if (!currentUser) {
                currentUser = new UserNode(username);
                currentUser->next = head;
                head = currentUser;
            }
        }
        else {
            // New notification
            notification = line.substr(2); // Remove "- " prefix
            currentUser->notifications.enqueue(notification);
        }
    }

    inFile.close();
    std::cout << "Notifications loaded from " << filePath << ".\n";
}
