#include "Queue.h"
#include <iostream>

template <typename T>
Queue<T>::Queue() {}

template <typename T>
void Queue<T>::enqueue(T value) {
    list.addBack(value);
}

template <typename T>
void Queue<T>::dequeue() {
    if (isEmpty()) {
        std::cerr << "Error: Queue is empty!\n";
        return;
    }
    list.removeFront();
}

template <typename T>
T Queue<T>::front() {
    if (isEmpty()) {
        throw std::runtime_error("Error: Queue is empty!");
    }
    return list.getFront();
}

template <typename T>
T Queue<T>::back() {
    if (isEmpty()) {
        throw std::runtime_error("Error: Queue is empty!");
    }
    return list.getBack();
}

template <typename T>
int Queue<T>::size() {
    return list.getSize();
}

template <typename T>
bool Queue<T>::isEmpty() {
    return list.isEmpty();
}

template <typename T>
void Queue<T>::printQueue() {
    std::cout << "Queue: ";
    list.printList();
}

// Explicit instantiation for common data types
template class Queue<int>;
template class Queue<std::string>;
