#ifndef BST_H
#define BST_H

#include <iostream>
#include <string>

class BST {
private:
    struct Node {
        std::string username;
        Node* left;
        Node* right;

        Node(const std::string& user) : username(user), left(nullptr), right(nullptr) {}
    };

    Node* root;

    void insert(Node*& node, const std::string& username);
    bool search(Node* node, const std::string& username);
    void inorderTraversal(Node* node);

public:
    BST();
    ~BST();

    void insert(const std::string& username);
    bool search(const std::string& username);
    void printInOrder();

    // Helper for memory cleanup
    void clear(Node* node);
};

#endif // BST_H
