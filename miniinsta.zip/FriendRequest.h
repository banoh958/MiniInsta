#ifndef FRIENDREQUEST_H
#define FRIENDREQUEST_H

#include "Queue.h"
#include <string>
#include <fstream>
class FriendRequestSystem {
private:
    struct UserNode {
        std::string username;
        Queue<std::string> friendRequests; // Queue to hold pending friend requests
        UserNode* next;

        UserNode(const std::string& name) : username(name), next(nullptr) {}
    };

    UserNode* head; // Head of the linked list of users

    UserNode* findUser(const std::string& username);

public:
    FriendRequestSystem();
    ~FriendRequestSystem();

    void sendFriendRequest(const std::string& from, const std::string& to);
    void showFriendRequests(const std::string& user);
    void acceptFriendRequest(const std::string& user);
    void rejectFriendRequest(const std::string& user);
    // File handling methods
    void saveFriendRequestsToFile(const std::string& filePath);
    void loadFriendRequestsFromFile(const std::string& filePath);
};

#endif // FRIENDREQUEST_H
