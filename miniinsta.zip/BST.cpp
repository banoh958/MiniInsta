#include "BST.h"

// Constructor
BST::BST() : root(nullptr) {}

// Destructor
BST::~BST() {
    clear(root);
}

void BST::clear(Node* node) {
    if (node) {
        clear(node->left);
        clear(node->right);
        delete node;
    }
}

void BST::insert(Node*& node, const std::string& username) {
    if (!node) {
        node = new Node(username);
        return;
    }
    if (username < node->username) {
        insert(node->left, username);
    }
    else if (username > node->username) {
        insert(node->right, username);
    }
}

void BST::insert(const std::string& username) {
    insert(root, username);
}

bool BST::search(Node* node, const std::string& username) {
    if (!node) {
        return false;
    }
    if (node->username == username) {
        return true;
    }
    if (username < node->username) {
        return search(node->left, username);
    }
    else {
        return search(node->right, username);
    }
}

bool BST::search(const std::string& username) {
    return search(root, username);
}

void BST::inorderTraversal(Node* node) {
    if (node) {
        inorderTraversal(node->left);
        std::cout << node->username << " ";
        inorderTraversal(node->right);
    }
}

void BST::printInOrder() {
    inorderTraversal(root);
    std::cout << "\n";
}
