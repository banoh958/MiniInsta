#ifndef SEARCHUSER_H
#define SEARCHUSER_H

#include <string>
#include <fstream>

class SearchUserSystem {
private:
    struct Node {
        std::string username;
        std::string password; // New field
        Node* left;
        Node* right;

        Node(const std::string& name, const std::string& pass)
            : username(name), password(pass), left(nullptr), right(nullptr) {
        }
    };

    Node* root; // Root of the BST

    void insert(Node*& node, const std::string& username, const std::string& password);
    bool search(Node* node, const std::string& username, const std::string& password);
    void inorderTraversal(Node* node);

public:
    SearchUserSystem();
    ~SearchUserSystem();

    void addUser(const std::string& username, const std::string& password);
    bool login(const std::string& username, const std::string& password);
    void displayAllUsers();
    void saveUsersToFile(const std::string& filePath);
    void loadUsersFromFile(const std::string& filePath);
    void clear(Node* node);
};

#endif // SEARCHUSER_H
