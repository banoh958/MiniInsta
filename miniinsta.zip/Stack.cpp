#include "Stack.h"
#include <iostream>

template <typename T>
Stack<T>::Stack() {}

template <typename T>
void Stack<T>::push(T value) {
    list.addFront(value);
}

template <typename T>
void Stack<T>::pop() {
    if (isEmpty()) {
        std::cerr << "Error: Stack is empty!\n";
        return;
    }
    list.removeFront();
}

template <typename T>
T Stack<T>::top() {
    if (isEmpty()) {
        throw std::runtime_error("Error: Stack is empty!");
    }
    return list.getFront();
}

template <typename T>
int Stack<T>::size() {
    return list.getSize();
}

template <typename T>
bool Stack<T>::isEmpty() {
    return list.isEmpty();
}

template <typename T>
void Stack<T>::printStack() {
    std::cout << "Stack (Top -> Bottom): ";
    list.printList();
}

// Explicit instantiation for common data types
template class Stack<int>;
template class Stack<std::string>;
